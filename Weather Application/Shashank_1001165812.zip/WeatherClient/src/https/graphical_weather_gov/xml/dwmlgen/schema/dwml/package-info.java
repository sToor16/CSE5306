@javax.xml.bind.annotation.XmlSchema(namespace = "https://graphical.weather.gov/xml/DWMLgen/schema/DWML.xsd")
package https.graphical_weather_gov.xml.dwmlgen.schema.dwml;
